package vehicle;

/** Construye StandardVehicle paso a paso y valida sus campos. */
public class StandardVehicleBuilder {
    private String brand;
    private Double weightKg, powerHp, fuelConsumption, costPerKm, maxSpeedKmh, accelerationSeconds, price;
    public StandardVehicleBuilder brand(String v) { brand=v; return this; }
    public StandardVehicleBuilder weightKg(double v) { weightKg=v; return this; }
    public StandardVehicleBuilder powerHp(double v) { powerHp=v; return this; }
    public StandardVehicleBuilder fuelConsumption(double v) { fuelConsumption=v; return this; }
    public StandardVehicleBuilder costPerKm(double v) { costPerKm=v; return this; }
    public StandardVehicleBuilder maxSpeedKmh(double v) { maxSpeedKmh=v; return this; }
    public StandardVehicleBuilder accelerationSeconds(double v) { accelerationSeconds=v; return this; }
    public StandardVehicleBuilder price(double v) { price=v; return this; }
    public StandardVehicle build() {
        if (brand == null || brand.isBlank()) throw new IllegalStateException("La marca es obligatoria");
        if (weightKg==null || powerHp==null || fuelConsumption==null || costPerKm==null || maxSpeedKmh==null || accelerationSeconds==null || price==null)
            throw new IllegalStateException("Completa todas las métricas antes de build()");
        if (weightKg<=0 || powerHp<=0 || fuelConsumption<0 || costPerKm<0 || maxSpeedKmh<=0 || accelerationSeconds<=0 || price<0)
            throw new IllegalArgumentException("Las métricas del vehículo tienen valores inválidos");
        return new StandardVehicle(brand,weightKg,powerHp,fuelConsumption,costPerKm,maxSpeedKmh,accelerationSeconds,price);
    }
}
