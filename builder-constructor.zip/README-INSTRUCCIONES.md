# Builder (Constructor)

Archivos nuevos: `vehicle/StandardVehicleBuilder.java` y `app/BuilderExample.java`. El fragmento `app/Main.baseVehicle-snippet.txt` muestra cómo conectar Builder con la aplicación. Copia los dos Java nuevos; si actualizas Main, coordina con Factory Method porque ambos tocarían ese archivo.

Compilar y ejecutar:
```powershell
javac -d out vehicle\*.java app\*.java
java -cp out app.BuilderExample
```

Commit y push:
```bash
git switch -c feat/vehicle-builder
git add vehicle/StandardVehicleBuilder.java app/BuilderExample.java app/Main.java
git commit -m "feat: add builder for standard vehicles"
git push -u origin feat/vehicle-builder
```
Abre un Pull Request a la rama principal. No incluyas `out/`; documenta las validaciones de `build()`.
