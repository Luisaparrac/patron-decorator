package app;
import vehicle.StandardVehicle;
import vehicle.StandardVehicleBuilder;
public class BuilderExample {
    public static void main(String[] args) {
        StandardVehicle v = new StandardVehicleBuilder().brand("Toyota Prado 2024").weightKg(2100).powerHp(201)
          .fuelConsumption(11.5).costPerKm(520).maxSpeedKmh(175).accelerationSeconds(11.0).price(290_000_000).build();
        System.out.println(v.getBrand() + " - precio: " + v.getPrice());
    }
}
